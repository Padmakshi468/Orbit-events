const Booking = require('../models/Booking');
const Event = require('../models/Event');

// @desc    Book an event — validates slots, prevents double booking, decrements slot count
// @route   POST /api/bookings/book-event
// @access  Private
const bookEvent = async (req, res) => {
  const { name, email, eventId } = req.body;

  if (!name || !email || !eventId) {
    return res.status(400).json({ success: false, message: 'Name, email and event ID are required' });
  }

  try {
    // 1. Find the event
    const event = await Event.findById(eventId);
    if (!event) {
      return res.status(404).json({ success: false, message: 'Event not found' });
    }

    // 2. Check if slots are available
    if (event.slotsBooked >= event.totalSlots) {
      return res.status(400).json({
        success: false,
        message: 'Sorry, this event is fully booked. No slots remaining.',
      });
    }

    // 3. Prevent the same user from booking the same event twice
    const alreadyBooked = await Booking.findOne({
      eventId,
      userId: req.user._id,
    });
    if (alreadyBooked) {
      return res.status(400).json({
        success: false,
        message: 'You have already booked this event.',
      });
    }

    // 4. Create booking
    const booking = await Booking.create({
      name,
      email,
      eventDate: event.date,
      eventId,
      userId: req.user._id,
    });

    // 5. Decrement available slots atomically
    await Event.findByIdAndUpdate(eventId, { $inc: { slotsBooked: 1 } });

    // 6. Fetch updated event to return fresh slot counts
    const updatedEvent = await Event.findById(eventId);

    res.status(201).json({
      success: true,
      message: 'Event booked successfully',
      booking: {
        _id: booking._id,
        name: booking.name,
        email: booking.email,
        eventDate: booking.eventDate,
        eventName: event.name,
        venueName: event.venueName,
        city: event.city,
      },
      slotsRemaining: updatedEvent.slotsRemaining,
    });
  } catch (error) {
    console.error('Booking error:', error);
    res.status(500).json({ success: false, message: 'Server error. Please try again.' });
  }
};

// @desc    Get all bookings for the logged-in user
// @route   GET /api/bookings/my
// @access  Private
const getMyBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ userId: req.user._id })
      .populate('eventId', 'name date venueName city totalSlots slotsBooked')
      .sort({ createdAt: -1 });
    res.json({ success: true, count: bookings.length, bookings });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = { bookEvent, getMyBookings };
